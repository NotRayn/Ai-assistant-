'use client';
import { useState } from "react";
import { askGemini } from "../lib/openai";

export default function Home() {
  const [input, setInput] = useState("");
  const [chat, setChat] = useState<string[]>([]);

  async function handleSend() {
    const userMessage = input;
    setChat([...chat, `👤: ${userMessage}`]);
    setInput("");

    const reply = await fetch('/api/ask', {
      method: "POST",
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ prompt: userMessage })
    });

    const data = await reply.json();
    setChat(prev => [...prev, `🤖: ${data.reply}`]);
  }

  return (
    <div className="p-4 max-w-xl mx-auto text-white">
      <h1 className="text-3xl font-bold mb-4">Gemini Assistant</h1>
      <div className="bg-gray-800 p-4 rounded h-96 overflow-y-auto space-y-2">
        {chat.map((line, idx) => (
          <div key={idx}>{line}</div>
        ))}
      </div>
      <div className="flex mt-4 gap-2">
        <input
          className="flex-1 p-2 rounded bg-gray-700"
          value={input}
          onChange={e => setInput(e.target.value)}
          placeholder="Ask something..."
        />
        <button onClick={handleSend} className="bg-blue-600 px-4 rounded">
          Send
        </button>
      </div>
    </div>
  );
}
